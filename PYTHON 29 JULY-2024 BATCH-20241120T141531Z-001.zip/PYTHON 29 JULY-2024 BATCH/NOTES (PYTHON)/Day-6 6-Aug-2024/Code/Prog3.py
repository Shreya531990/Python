#Example :

if True :
    

for i in range(3) :
    pass
