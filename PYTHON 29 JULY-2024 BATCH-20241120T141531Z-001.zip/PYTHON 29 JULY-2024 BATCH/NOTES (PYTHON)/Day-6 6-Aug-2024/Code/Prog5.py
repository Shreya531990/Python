#WAP to check all prime number between 10 to 20..
#Nested Loop

for num in range(10,100):
    flag=True
    for i in range(2,num):
        if num % i ==0 :
            flag=False
            break
    if flag==True:
        print(f'{num} is prime number')
    
