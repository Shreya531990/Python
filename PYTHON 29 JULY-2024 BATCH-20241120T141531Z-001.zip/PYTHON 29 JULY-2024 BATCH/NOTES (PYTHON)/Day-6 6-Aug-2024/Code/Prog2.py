#Example 2 : When ever we input number 5 then loop will continue
#            with next number other print square of number.


while True:
    num = int(input('Enter any number '))
    if num == 5 :
        continue
    elif num == -1 :
        break
    print('Square of num ',num*num)
   
print('Program end here...')
