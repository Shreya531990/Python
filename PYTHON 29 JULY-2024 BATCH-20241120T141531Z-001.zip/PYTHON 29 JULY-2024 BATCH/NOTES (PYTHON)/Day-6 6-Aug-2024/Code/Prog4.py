#WAP to check given number is Prime or Not Prime

num = int(input('Enter any number '))

flag=True
for i in range(2,num):
    if num % i==0 :        
        flag=False

if flag == True:
    print('Number is prime')
else:
    print("Not Prime")





