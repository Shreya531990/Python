'''
Example 1 : To print odd numbers in the range 0 to 9
'''

for i in range(10):
    if i % 2 == 0:
        continue
    print('Odd Number : ',i)


print('Program end here...')
