from  tkinter import *
from tkinter import filedialog
from PIL import Image ,ImageTk
import os

main = Tk()
main.title('My First App')

w = main.winfo_screenwidth()
h = main.winfo_screenheight()

main.geometry("%dx%d+0+0"%(w,h))
main.resizable(0,0)

#Functions
def upload_image():
    imgPath = filedialog.askopenfilename(initialdir = os.getcwd())
    print('Image Path ',imgPath)
    global selectedpicture
    selectedpicture = ImageTk.PhotoImage(file = imgPath)
    lblImage.configure(image=selectedpicture,height=150,width=150)



#Frames Design
frmTop = Frame(main,height=100,width=600,bg='Red')
frmTop.pack(fill=X)

frmMid = Frame(main,height=100,width=w,bg='Yellow')
frmMid.pack(side=LEFT,fill=Y)

frmBottom = Frame(main,height=100,width=100,bg='Green')
frmBottom.pack(side=BOTTOM,fill=Y)

frmLeft = Frame(frmMid,height=200,width=200,bg='lightgreen')
frmLeft.pack(side=LEFT,fill=Y)

frmCenter = LabelFrame(frmMid,text="Student Info",height=200,width=600,bg='yellow')
frmCenter.pack(side=LEFT,padx=5,pady=5,fill=Y)

frmRight = LabelFrame(frmMid,text="Student Image",height=200,width=600,bg='yellow')
frmRight.pack(side=LEFT,padx=5,pady=5,fill=Y)
#Widgets
lblHeading = Label(frmTop,text='Welcome to TG',font=("impact",30),bg="Red",fg="Yellow")
lblHeading.pack(pady=20)

lblRollNo = Label(frmLeft,text="Roll No ")
lblRollNo.place(x=10,y=10)

#Image Upload
lblImage = Label(frmRight,text='Image')
lblImage.pack()

btnUpload = Button(frmRight,text='Upload',command = upload_image)
btnUpload.pack(pady=5)


main.mainloop()

