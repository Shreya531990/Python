from  tkinter import *

main = Tk()
main.title('My First App')

w = main.winfo_screenwidth()
h = main.winfo_screenheight()

main.geometry("%dx%d+0+0"%(w,h))
main.resizable(0,0)

frmTop = Frame(main,height=100,width=600,bg='Red')
frmTop.pack(fill=X)

frmMid = Frame(main,height=100,width=w,bg='Yellow')
frmMid.pack(side=LEFT,fill=Y)

frmBottom = Frame(main,height=100,width=100,bg='Green')
frmBottom.pack(side=BOTTOM,fill=Y)

frmLeft = Frame(frmMid,height=200,width=200,bg='Purple')
frmLeft.pack(side=LEFT)
frmCenter = Frame(frmMid,height=200,width=600,bg='Blue')
frmCenter.pack(side=LEFT)



main.mainloop()

