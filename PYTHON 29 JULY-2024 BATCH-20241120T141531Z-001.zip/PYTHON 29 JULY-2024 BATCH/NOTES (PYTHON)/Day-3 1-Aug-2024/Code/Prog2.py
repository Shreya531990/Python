a = int(input('Enter value of a '))
b = int(input('Enter Value of b '))

#a = 10
#b = 20

result = a + b
print('Result ',result)
