#Logical Operators :
# and , or , not

#A. and 	==> If both arguments are True then only result is True.


result = 10 > 20 and 10 > 30
print('Result ',result)

result = 10 < 20 and 10 < 30
print('Result ',result)

result = 10 > 20 and 10 < 30
print('Result ',result)

result = 10 < 20 and 10 > 30
print('Result ',result)


username = input('Enter User Name ')
password = input('Enter Password')

result = username == 'admin' and password =='password'
print('Result ',result)
