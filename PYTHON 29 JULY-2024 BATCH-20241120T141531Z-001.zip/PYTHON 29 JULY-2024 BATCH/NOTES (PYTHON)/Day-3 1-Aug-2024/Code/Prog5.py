#Arithmetic Operators. :

result = 10 + 20
print('Result ',result)

result = 10 - 20
print('Result ',result)

result = 10 * 20
print('Result ',result)

result = 22 / 7
print('Result ',result)

result = 22 // 7
print('Result ',result)

result = 22 % 7
print('Result ',result)

result = 2 ** 5
print('Result ',result)

#int(result) =22 // 7

result = 22 / 7
print('Result ',result)
result = int(result)
print('Result ',result)
