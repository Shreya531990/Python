#int(result) = 22 // 7

result = 22 / 7
print('Result ',result)

result = int(result)
print('Result ',result)


result = int(22/7)
print('Result ',result)
