#Relational Operators :-
'''
>	==>	Greater Than
>=	==>	Greater Than Equal To
<	==> 	Less Than
<=	==>	Less Than Equal To

It use to compare two values or numbers and return result in form bool values ( True or False)
'''
a = 10
b = 20

print("a  < b ",a > b)
