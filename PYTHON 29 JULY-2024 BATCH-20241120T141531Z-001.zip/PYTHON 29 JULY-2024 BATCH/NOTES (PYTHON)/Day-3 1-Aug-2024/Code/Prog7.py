#WAP (Write A Program) to swap two number 

#Solution : 
a = 10
b = 20

print('Before Swapping ')
print('Value of a ',a)
print('Value of b ',b)

#Logic 1
#c = a
#a = b
#b = c

#Logic 2
a = a + b
b = a - b
a = a - b 

#a,b = b, a #Internally work on tuple data type. 

print('\nAfter Swapping ')
print('Value of a ',a)
print('Value of b ',b)
