#5. Assignment Operators.

num = 10
print('Value of num ',num)

num2 = num
print('Value of num2 ',num2)


#Compounded Assignment Operator
num += 10 # num = num + 10 
print('Value of num ',num)



