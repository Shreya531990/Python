#B. or 	==> If atleast one argument is True then result is True

result = 10 > 20 or 10 > 30
print('Result ',result)

result = 10 < 20 or 10 < 30
print('Result ',result)

result = 10 > 20 or 10 < 30
print('Result ',result)

result = 10 < 20 or 10 > 30
print('Result ',result)


username = input('Enter User Name ')
password = input('Enter Password')

result = username == 'admin' or password =='password'
print('Result ',result)
