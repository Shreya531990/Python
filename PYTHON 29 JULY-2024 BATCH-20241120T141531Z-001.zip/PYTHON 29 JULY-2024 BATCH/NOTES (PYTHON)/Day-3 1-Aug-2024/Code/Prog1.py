'''
Input() Function :

Input() function can be used to read data directly at runtime and
every input value is treated as str type only. 
'''

name = input('Enter Your Name ')
print('Your name is ',name)


