#Multiple Value input

a,b,c = input('Enter value a , b and c ').split()

print('Value of a ',a)
print('Value of b ',b)
print('Value of c ',c)
