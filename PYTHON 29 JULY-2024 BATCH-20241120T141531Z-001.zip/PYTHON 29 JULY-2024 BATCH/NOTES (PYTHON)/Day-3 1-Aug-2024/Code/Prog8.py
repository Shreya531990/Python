#WAP (Write A Program) to swap two number 

#Solution : 
a = 10
b = 20
c = 30
print('Before Swapping ')
print('Value of a ',a)
print('Value of b ',b)
print('Value of c ',c)

a,b,c = b,c,a #Internally work on tuple data type. 

print('\nAfter Swapping ')
print('Value of a ',a)
print('Value of b ',b)
print('Value of c ',c)
