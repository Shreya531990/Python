#2. Membership Operators :

x = 'The Quick Brown Fox Jumps Over A Lazy Dog.'

print('Fox' in x)   #True
print('Cat' in x)   #False


lst = [10,123,34,102,345,21]

result = 10 in lst
print('Result ',result)
