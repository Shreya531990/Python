#Ordering elements of List : 
#1. reverse() : We can use to reverse() order of elements of list

fruits = ['Mango','Orange','Kiwi','Banana','Grapes']

print('Fruist List : ',fruits)
fruits.reverse()

print('Reverse Fruits List : ',fruits)



#Sorting a List :

#Sorting a List :
fruits = ['Mango','Orange','Kiwi','Banana','Grapes']

print('Fruist List : ',fruits)

fruits.sort()

print('Sorted Fruist List : ',fruits)




#Reverse Sorting a List :
fruits = ['Mango','Orange','Kiwi','Banana','Grapes']

print('Fruist List : ',fruits)

fruits.sort(reverse=True)

print('Reverse Sorted Fruist List : ',fruits)



