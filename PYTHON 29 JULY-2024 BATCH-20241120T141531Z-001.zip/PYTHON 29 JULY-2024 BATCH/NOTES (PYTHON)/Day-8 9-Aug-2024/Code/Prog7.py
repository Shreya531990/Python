#5. with split() function


s = 'The Quick Brown Fox'

lst = s.split()
print('List ',lst)
print('Type ',type(lst))	
