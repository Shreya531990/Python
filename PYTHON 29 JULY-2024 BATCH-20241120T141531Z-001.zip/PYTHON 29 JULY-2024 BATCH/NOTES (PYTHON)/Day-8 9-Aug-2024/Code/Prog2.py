
#2 If we know elements already then we can  create list as follow.
lst = [10,20,30,40,50]
print('List ',lst)
print('Type ',type(lst))
