a = eval(input("enter your expression "))
print(a)
