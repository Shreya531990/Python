#Creation of List Objects

#1. We can create empty list object as follow
lst = []
print('List ',lst)
print('Type ',type(lst))
