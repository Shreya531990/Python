#Use of extend function in list
lst_a=['Rakesh','Sumit','Kapil']

lst_b =['Deepak','Amit']

print('List A : ',lst_a)
print('List B : ',lst_b)

#lst_a.append(lst_b)
lst_a.extend(lst_b)
print('List A : ',lst_a)

