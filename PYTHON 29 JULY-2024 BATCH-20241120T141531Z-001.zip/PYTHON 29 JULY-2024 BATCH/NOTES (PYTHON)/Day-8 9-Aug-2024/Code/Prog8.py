#1. By using index :
lst = ['Mango','Orange','Kiwi','Potato','Tomato']
print('List[3]',lst[3])
print('List[-1]',lst[-1])
