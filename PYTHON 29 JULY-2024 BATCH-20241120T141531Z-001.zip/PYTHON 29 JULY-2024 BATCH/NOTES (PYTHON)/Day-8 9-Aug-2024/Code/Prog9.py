lst = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

print(lst[2:5])
print(lst[::2])
print(lst[::-1])
