#Traversing the elements of List Object : 
#The sequential access of each elements in the list is called Traversal. 

fruits = ['Mango','Orange','Kiwi','Banana','Grapes']

for fruit in fruits :
    print(fruit)
