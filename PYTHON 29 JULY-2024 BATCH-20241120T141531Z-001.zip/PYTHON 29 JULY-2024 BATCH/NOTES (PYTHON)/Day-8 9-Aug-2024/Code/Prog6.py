#4. With list() function:
lst = list(range(1,11))
print('List ',lst)
print('Type ',type(lst))



name = 'Delhi'

lst = list(name)
print('List ',lst)
print('Type ',type(lst))
