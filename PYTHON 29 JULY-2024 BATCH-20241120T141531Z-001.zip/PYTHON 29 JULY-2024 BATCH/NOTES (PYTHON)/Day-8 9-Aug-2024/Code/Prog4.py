msg = int(input('Enter any expression'))
print('Message' ,msg)
