#List vs Mutability:

fruits = ['Mango','Orange','Kiwi','Banana','Grapes']
print('List Fruits : ',fruits)
print('Id : ',id(fruits))


index = fruits.index('Orange')
print('Index Number ',index)

fruits[index]=1200
print('List Fruits : ',fruits)
print('Id : ',id(fruits))
