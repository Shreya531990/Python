
#3. With dynamic input :

lst  = eval(input('Enter List : '))
#lst  = input('Enter List : ')

print('List ',lst)
print('Type ',type(lst))

