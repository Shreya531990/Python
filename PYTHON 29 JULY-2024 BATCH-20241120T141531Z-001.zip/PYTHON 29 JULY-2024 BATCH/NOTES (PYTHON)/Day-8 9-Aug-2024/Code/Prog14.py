#Use of Pop and Remove Function in list object
fruits = ['Mango','Orange','Kiwi','Banana','Grapes']

element = fruits.pop()  # pop() it will remove last element from list
print('Pop element ',element)
print('List ',fruits)


element = fruits.pop(1)  # pop(index) it will remove last element from list
print('Pop element ',element)
print('List ',fruits)


fruits.remove('Kiwi')
print('List ',fruits)
