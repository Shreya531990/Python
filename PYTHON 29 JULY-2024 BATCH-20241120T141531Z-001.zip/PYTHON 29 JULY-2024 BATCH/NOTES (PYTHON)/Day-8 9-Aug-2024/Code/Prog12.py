# Manipulating elements of List :
#1. append() function : We can use append() function to add item at the end of the list. 

#Example : 
lst=[]
print('List : ',lst)    #Output : List :  []

lst.append('Delhi')
print('\nList : ',lst)  #Output : List :  ['Delhi']


lst.append('Mumbai')
print('\nList : ',lst)  #Output : List :  ['Delhi', 'Mumbai']


