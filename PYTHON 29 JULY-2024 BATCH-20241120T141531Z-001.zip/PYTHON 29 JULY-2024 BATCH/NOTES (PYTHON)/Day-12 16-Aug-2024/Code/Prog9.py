#1.union():
'''
x.union(y) ==>We can use this function to return all elements present in both sets

x.union(y) or x|y

Eg:
'''
set_x={10,20,30,40}

set_y={30,40,50,60}

print(set_x.union(set_y))   #Output : {10, 20, 30, 40, 50, 60}

print(set_x|set_y)          #Output : {10, 20, 30, 40, 50, 60}


new_set = set_x.union(set_y)
print('Union Set ',new_set)
