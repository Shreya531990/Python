#4.symmetric_difference():
''''
x.symmetric_difference(y) or x^y

Returns elements present in either x or y but not in both

Eg:
'''

x={10,20,30,40}
y={30,40,50,60}

print(x.symmetric_difference(y)) #{10, 50, 20, 60}

print(x^y) #{10, 50, 20, 60
