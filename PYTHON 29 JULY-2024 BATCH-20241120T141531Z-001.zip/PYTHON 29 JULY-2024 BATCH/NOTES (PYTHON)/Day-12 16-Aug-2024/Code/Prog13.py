#Set Comprehension:

#Set comprehension is possible.

s={x*x for x in range(5)}
print(s) #{0, 1, 4, 9, 16}

s={2**x for x in range(2,10,2)}
print(s) #{16, 256, 64, 4}

