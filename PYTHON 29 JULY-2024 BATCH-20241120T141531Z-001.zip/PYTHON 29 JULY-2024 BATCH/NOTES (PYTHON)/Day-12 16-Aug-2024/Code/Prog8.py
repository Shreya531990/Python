#6. discard(x):
'''
It removes the specified element from the set.
If the specified element not present in the set then we won't get any error.
'''
s={10,20,30}
print('Value of Set Object s ',s)
print('Id of Set Object s ',id(s))

s.discard(10)

print('\nAfter discard item from Set Object')
print('Value of Set Object s ',s)
print('Id of Set Object s ',id(s))

s.discard(10)
print('\nAfter discard item from Set Object')
print('Value of Set Object s ',s)
print('Id of Set Object s ',id(s))
