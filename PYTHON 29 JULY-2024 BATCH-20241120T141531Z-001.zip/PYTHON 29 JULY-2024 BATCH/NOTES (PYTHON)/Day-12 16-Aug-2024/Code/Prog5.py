#4. pop():

#It removes and returns some random element from the set.
#Eg:

s={40,10,30,20} 

print(s) 
print('Poped Item : ',s.pop()) 
print(s) 
