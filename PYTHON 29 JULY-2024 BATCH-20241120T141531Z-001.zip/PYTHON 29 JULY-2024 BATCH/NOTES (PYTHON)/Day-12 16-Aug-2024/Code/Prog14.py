#set objects won't support indexing and slicing:

#Eg:

s={10,20,30,40}

print(s[0])   #==>TypeError: 'set' object does not support indexing
print(s[1:3]) #==>TypeError: 'set' object is not subscriptable
