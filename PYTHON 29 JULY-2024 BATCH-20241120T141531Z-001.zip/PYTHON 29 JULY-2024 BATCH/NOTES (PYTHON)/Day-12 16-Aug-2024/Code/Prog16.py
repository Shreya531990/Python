#Frozen Set Object : Immutable

lst = [10,20,30,40,10,20,30,20,10]

set_x = set(lst)
print('Set_x ',set_x)
print('Type of Set_x ',type(set_x))

set_x.add(100)





f_set = frozenset(lst)
print('Frozenset f_set ',f_set)
print('Type of f_set',type(f_set))
f_set.add(100) #AttributeError: 'frozenset' object has no attribute 'add'
