#2. intersection():
'''
x.intersection(y) or x&y

Returns common elements present in both x and y

Eg:
'''
set_x={10,20,30,40}
set_y={30,40,50,60}


set_z = set_x.intersection(set_y)

print('Intersection of Set_x and Set_y ',set_z)

#Output : {40, 30}
