#5. remove(x):
'''
It removes specified element from the set.
If the specified element not present in the Set then we will get KeyError
'''

s={40,10,30,20}
s.remove(30)
print(s) # {40, 10, 20}


s.remove(50) #==>KeyError: 50
