#3. copy():

#Returns copy of the set.
#It is cloned object.

s={10,20,30}

s1=s.copy()

print(s)
print('Id ',id(s))

print(s1)
print('Id ',id(s1))
