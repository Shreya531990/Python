#Creation of Set objects:

s={10,20,30,40} 
print(s) 
print(type(s)) 
 
s2 = set(range(20))
print(s2)


lst = [10,20,20,10,10,40,50,50,20,40,50,50,10]
s3 = set(lst)
print(s3)
