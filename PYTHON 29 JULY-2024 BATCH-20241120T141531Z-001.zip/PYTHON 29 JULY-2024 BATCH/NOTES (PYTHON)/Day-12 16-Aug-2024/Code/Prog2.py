#Important functions of set:

#1. add(x):
#Adds item x to the set
#Eg:

s={10,20,30}
print('Set s ',s)

s.add(40)
s.add(25)
s.add(25)
s.add(55)

print('After Add Element ',s) #{40, 10, 20, 30} 
