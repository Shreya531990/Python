#3. difference():
'''
x.difference(y) or x-y

returns the elements present in x but not in y

Eg:
'''

set_x={10,20,30,40}
set_y={30,40,50,60}

print(set_x.difference(set_y))  #Output : {10, 20}

print(set_x-set_y)              #Output : {10, 20}

print(set_y-set_x)              #Output : {50, 60}
