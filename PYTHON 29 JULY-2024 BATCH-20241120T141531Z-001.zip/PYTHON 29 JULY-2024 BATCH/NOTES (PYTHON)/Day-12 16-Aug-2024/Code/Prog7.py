lst_names = ['Rakesh','Sumit','Rakesh','Rakesh','Sumit','Dinesh','Deepak','Rajesh','Rakesh','Sumit','Sunil','Dheeraj','Deepak','Kapil']

unique_names = set(lst_names)
print(unique_names)



