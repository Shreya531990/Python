#7. range : To represent a range of values. It is also immutable. 

r = range(10)
print('Range r ',r)
print('Type of r ',type(r))

'''
for i in r:    
              print('Welcome to Technical Guftgu')
'''

for a in range(10):
    print(a)

num=1
while num<10:
    print(num)
    num = num+1
