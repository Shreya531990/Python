#5. Str : To represent sequence of characters : It is also immutable. 
#str data type : To represent seaquence of characters.

s1 = "Delhi"
print('s1 ',s1)
print('Type of s1  ',type(s1))
print('Id of s1 ',id(s1))

print('Value s1[0] ',s1[0])
#s1[0] = 'M' #TypeError: 'str' object does not support item assignme

s1='Mumbai'
print('s1 ',s1)
print('Type of s1  ',type(s1))
print('Id of s1 ',id(s1))


