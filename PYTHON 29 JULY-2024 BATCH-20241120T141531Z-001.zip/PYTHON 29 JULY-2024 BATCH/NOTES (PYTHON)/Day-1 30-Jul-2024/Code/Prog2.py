age1 = 21
print('Value of age  ',age1)
print('Id of age 1 ',id(age1))

age2 = 21
print('Value of age  ',age2)
print('Id of age 2 ',id(age2))


age2 = 50

print('Value of age  ',age1)
print('Id of age 1 ',id(age1) )

print('Value of age  ',age2)
print('Id of age 2 ',id(age2))
