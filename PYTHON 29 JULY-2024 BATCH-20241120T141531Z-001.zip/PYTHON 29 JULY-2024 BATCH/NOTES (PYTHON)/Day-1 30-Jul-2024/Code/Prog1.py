print('Hello Python')
print('Welcome to Technical Guftgu')
