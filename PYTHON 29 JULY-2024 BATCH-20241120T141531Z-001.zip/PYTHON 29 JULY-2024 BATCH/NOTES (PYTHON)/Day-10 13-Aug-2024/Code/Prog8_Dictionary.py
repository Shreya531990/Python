#How to access data from the dictionary?

#We can access data by using keys

d1 = {101:'Mango',102:'Sunday',103:'Delhi'}

print(d1[101])   #Output : Mango
print(d1[102])  #Output : Sunday

#print(d1[500])  #KeyError: 500

#We can prevent this by checking whether keyis already or not by using in operator 

if 300 in d1 :
      print(d1[300])
