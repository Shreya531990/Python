data ={
    "marketState": [
        {
            "market": "Capital Market",
            "marketStatus": "Closed",
            "tradeDate": "13-Aug-2024 15:30",
            "index": "NIFTY 50",
            "last": 24139,
            "variation": -208,
            "percentChange": -0.85,
            "marketStatusMessage": "Normal Market has Closed"
        },
        {
            "market": "Currency",
            "marketStatus": "Closed",
            "tradeDate": "13-Aug-2024",
            "index": "",
            "last": "",
            "variation": "",
            "percentChange": "",
            "marketStatusMessage": "Market is Closed"
        },
        {
            "market": "Commodity",
            "marketStatus": "Open",
            "tradeDate": "13-Aug-2024",
            "index": "",
            "last": "",
            "variation": "",
            "percentChange": "",
            "marketStatusMessage": "Market is Open"
        },
        {
            "market": "Debt",
            "marketStatus": "Closed",
            "tradeDate": "13-Aug-2024",
            "index": "",
            "last": "",
            "variation": "",
            "percentChange": "",
            "marketStatusMessage": "Market is Closed"
        }]}

for d in data['marketState']:
    print('\nMarket ',d['market'])
    print('Trade Date ',d['tradeDate'])
    

