lst=('Bhupendra',)
print('List:',lst)
print('Type:',type(lst))
