#How to create Dictionary ?

d = {} # or d = dict()

#We are creating empty dictionary. We can add entries as follows. 

d[100] = 'Delhi'
d[101] = 'Mango'
d[300] = 'Sunday'


print(d)  # {100 : 'Delhi', 101 : 'Mango', 300 :'Sunday'}
print(type(d))
