t1 = (10,40,50,30,20,10,10)

print('Length of Tuple ',len(t1))

print('Count of 10 in Tuple ',t1.count(10))

print('Index of 30 in Tuple ',t1.index(30))
