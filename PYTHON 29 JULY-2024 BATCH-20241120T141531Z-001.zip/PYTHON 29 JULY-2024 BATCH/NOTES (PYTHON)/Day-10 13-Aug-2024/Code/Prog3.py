#4. sorted() : To sort elements based on default natural sorting order.

t1 = (10,40,50,30,20,10,10)


print('Unsorted Tuple ',t1)
print('Type ',type(t1))
print('Id ',id(t1))

t1 = tuple(sorted(t1)) #It return a list object


print('\nAfter Sorted')

print('Sorted Tuple 2',t1)
print('Type ',type(t1))
print('Id ',id(t1))



t2 = tuple(sorted(t1,reverse=True)) #It return a list object

print('\nAfter Reverse Sorted')

print('Sorted Tuple 2',t2)
print('Type ',type(t2))
