#Tuple Packing and Unpacking :
'''
We can create a tuple by packing a group of variables 

Example :
'''

a = 10
b = 20
c = 30

t = a,b,c
print('Tuple t ',t)


#p,q = t

a,b,c = t
print('\nValue of a ',a)
print('Value of b ',b)
print('Value of c ',c)
