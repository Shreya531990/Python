lst = [10]
print('List : ',lst)
print('Type :',type(lst))

t1 = (10,)
print('\nTuple : ',t1)
print('Type :',type(t1))
