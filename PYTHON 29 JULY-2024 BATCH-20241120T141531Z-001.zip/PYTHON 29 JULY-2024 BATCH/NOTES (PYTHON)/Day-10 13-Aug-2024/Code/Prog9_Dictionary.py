#How to update dictionaries ?
'''
d [key] = value

If the key is not available then
new entry will be added to the dictionary
with the specified key-value pair.

If the key is already then old value will be
replaced with new value

'''

student_info={'rollno':101,'name':'Rakesh','marks':400}

print('Student Info ')
print(student_info)

student_info['name']='Mohit'

print('Updated Student Info ')
print(student_info)

student_info['location']='Delhi'

print('Updated Student Info ')
print(student_info)



print('\n------- Student Info --------')
for key, value in student_info.items():
    print(f"{key} : {value}")

#Output 
'''
------- Student Info --------
rollno : 101
name : Mohit
marks : 400
location : Delhi
'''





    
