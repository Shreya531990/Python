lst1 = [30,20,10,50,40]

print('Before Sorting')
print('List ',lst1)
print('ID : ',id(lst1))

lst1.sort()
print('\nAfter Sorting')
print('List ',lst1)
print('ID : ',id(lst1))


#Reverse Sorting
lst1.sort(reverse=True)
print('\nAfter Reverse Sorting')
print('List ',lst1)
print('ID : ',id(lst1))


