#How to delete elements from dictionary ?
'''
del d[key]

It deletes entry associated with the specified key
If the key is not available then we will get KeyError
'''

d1={}

d1[101] =['rakesh',400,'Delhi']
d1[102] =['sumit',500,'Mumbai']
d1[103] =['deepak',200,'Goa']


print('Student Info')

for key , value in d1.items():
    print(f"{key} : {value}")


del d1[102]

print('\n Updated Student Info')

for key , value in d1.items():
    print(f"{key} : {value}")

del d1[102] #KeyError : 102
