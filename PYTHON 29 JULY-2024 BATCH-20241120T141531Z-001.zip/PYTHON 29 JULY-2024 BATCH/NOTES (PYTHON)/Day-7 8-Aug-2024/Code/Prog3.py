s1='The Quick Brown Fox'

for i in range(len(s1)-1,-1,-1):
    print(s1[i],end='')


print(s1[::-1])


