#Split and Join Methods in Python string object

city = 'New Delhi'

print(city.split()) # Bydefault split method split string by space...

student_info = 'Rollno,Name,Marks,Location'

print(student_info.split(','))

lst1 = ['101','Rakesh','400','Delhi']

record = ','.join(lst1)
print(record)
