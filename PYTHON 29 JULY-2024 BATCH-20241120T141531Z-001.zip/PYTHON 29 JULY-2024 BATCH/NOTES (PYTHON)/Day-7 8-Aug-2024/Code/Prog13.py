#To check type of characters present in a string...
'''
Python contains the following methods for this purpose...

1. isalnum() : Returns True if all character are alphanumeric ( a to z, A to Z, 0 to 9)
2. isalpha() : Returns True if all character are only alphabets ( a to z, A to Z)
3. isdigit()
4. islower()
5.isupper()
6.istitle()
7.isspace() : Return True if string contains only space....
'''

name ='Bangalore123'

print('isalnum() ',name.isalnum())
print('isalpha() ',name.isalpha())
print('isdigit() ',name.isdigit())
print('isspace() ',name.isspace())
