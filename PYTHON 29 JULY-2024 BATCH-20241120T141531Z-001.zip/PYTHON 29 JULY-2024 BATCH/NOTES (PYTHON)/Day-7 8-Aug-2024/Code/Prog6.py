#Counting substring in the given String:
'''
We can find the nubmer of occurence of substring present in the given string by using count() method.

1. s.count(substring)		==> It will search through out the string.
2. s.count(substring,begin,end) == > It will search from begin index to end-1 index.

Example 1 :
'''

msg = 'The Quick Brown foxJumps Over A Lazy Dog fox fox'

print(msg.count('fox'))     #Output 3
print(msg.count('fox',20))  #Output 2
