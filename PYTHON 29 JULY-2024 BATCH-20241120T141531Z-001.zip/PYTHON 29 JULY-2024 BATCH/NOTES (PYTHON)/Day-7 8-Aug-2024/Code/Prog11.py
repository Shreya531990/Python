#Checking starting and ending part of the string....
'''
Python contains the following methods for this purpose....

1. s.startswith(substring)
2. s.endswith(substring)

Example :
'''
s = 'Learning Python is very easy'

print(s.startswith('Learning'))  #Output : True
print(s.startswith('Python'))  #Output : False


print(s.endswith('Easy'))  #Output : False
print(s.endswith('easy'))  #Output : True
