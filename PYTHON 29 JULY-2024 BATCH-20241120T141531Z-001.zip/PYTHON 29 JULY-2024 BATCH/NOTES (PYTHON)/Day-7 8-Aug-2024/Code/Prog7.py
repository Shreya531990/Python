#Replacing a string with another string:

#s.replace(oldstring,newstring)

s1='I live in Delhi \n I am a student of DU \n I want to excel.'

s1 = s1.replace('\n','')
s1 = s1.replace('Delhi','Mumbai')
print(s1)


