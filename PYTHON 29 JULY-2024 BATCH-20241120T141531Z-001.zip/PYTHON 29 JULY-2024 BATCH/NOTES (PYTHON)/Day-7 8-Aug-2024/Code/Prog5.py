#Example 2 :

city = input('Enter your city name ')

city = city.strip()

if city == 'Delhi':
    print('Hello I am from Delhi')
elif city == 'Noida' :
    print('Hello I am from Noida')
elif city=='New Delhi':
    print('Hello I am from New Delhi')
else:
    print('Sorry, I am not able to understand')
