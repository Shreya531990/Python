citynames = ['Bangalore','Bangallore','Bangalore1','Banguluru','Bangalore2']

for city in citynames:
    if city.startswith('Bangalore'):
        print(city)


    
