#Changing case of a String :
'''We can change case of a string by using the following 4 methods.

1. upper()
2. lower()
3. swapcase()
4. title()
5. capitalise()
'''

s = 'the quick BROWN fox jumps over a lazy DOG'

print('String : ',s)
print('1. upper() : ',s.upper())
print('2. lower() : ',s.lower())
print('3. swapcase() : ',s.swapcase())
print('4. title() : ',s.title())
print('5. capitalize() : ',s.capitalize())
