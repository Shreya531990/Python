s = 'The Quick Brown Fox'
sub1 = s[:-10]
print(sub1)


i=0
for ch in s:
    print(f"{i} : {ch}")
    i=i+1



for i in range(len(s)):
    print(f"{i} : {s[i]}")
