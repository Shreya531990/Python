s='Delhi'
sub1 = s[-1:-6:-2]
print('Main String ',s)
print('Sub String ',sub1)
