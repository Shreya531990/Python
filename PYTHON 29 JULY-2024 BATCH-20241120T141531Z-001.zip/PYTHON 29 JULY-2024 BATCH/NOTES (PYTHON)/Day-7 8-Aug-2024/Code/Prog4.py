state1 = ' Rajasthan '
state2 = '   Gujrat   '
print(state1 + state2)

state1 = state1.strip()
state2 = state2.strip()
print(state1 + state2)
