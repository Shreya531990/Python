#Splitting of Strings:
'''
We can split the given string according to specified seperator by using split() method.

The default seperator is space. The return type of split() method is List. 
'''

s = 'The Quick Brown Fox Jumps Over A Lazy Dog'
lst = s.split()
print('List ',lst)


for word in lst:
    print(word)
