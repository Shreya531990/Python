#7. keys() : It returns all keys associated with dictionary
language = {101:'Python',102:'Java',103:'Ruby',104:'Perl'}
print('Language ',language)
print('language.keys() : ',language.keys())


#8. values() : It returns all values associated with dictionary
print('\n\nLanguage ',language)
print('language.values() : ',language.values())

#9 items(): It returns list of tuples represent key-value pair.
print('\n\nLanguage ',language)
print('language.items() : ',language.items())
