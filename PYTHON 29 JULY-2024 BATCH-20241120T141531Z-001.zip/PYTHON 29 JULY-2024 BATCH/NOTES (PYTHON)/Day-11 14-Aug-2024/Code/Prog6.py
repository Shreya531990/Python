#11. setdeafult():
'''
d.setdefault(key,value) :
	It the key is already available then this function returns the corresponding value. 
	It the key is not available then the specified key-value will be added as new item to the dictionary. 
'''

language = {101:'Python',102:'Java',103:'Ruby',104:'Perl'}
print('Language ',language)

value = language.setdefault(102,'Java Script')
print('\nValue : ',value)

print('\nLanguage ',language)

value = language.setdefault(105,'Java Script')
print('\nValue : ',value)

print('\nLanguage ',language)
