bank={}
account=[]
for i in range(5):
     accno = int(input('entre Account : '))
     account.append(input('entre Nmae : '))
     account.append(int(input('entre Balance : ')))
     bank[accno]=account.copy()
     account.clear()
                           
print('\n\nAccount detais')
for key,value in bank.items():
    print(f'{key} :{value} ')
