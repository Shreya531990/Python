#6. popitem() :
'''
    It remove an arbitrary item (key-value) from the dictionary and return it. 
    If the dictionary is empty then we will get KeyError
'''

language = {101:'Python',102:'Java',103:'Ruby',104:'Perl'}

print('Language ',language)

print('language.popitem()',language.popitem())

print('Language ',language)

language.clear()
print('language.popitem()',language.popitem())

