#12. update():  All items present in the
#dictionary A will be added to dictionary B.


A = {101:'Mango',102:'Orange',103:'Kiwi'}
B = {103 :'Saturday', 104:'Sunday',105:'Monday'}

print('Dictionary A : ',A)
print('\nDictionary B : ',B)


B.update(A)
print('\nDictionary B : ',B)
