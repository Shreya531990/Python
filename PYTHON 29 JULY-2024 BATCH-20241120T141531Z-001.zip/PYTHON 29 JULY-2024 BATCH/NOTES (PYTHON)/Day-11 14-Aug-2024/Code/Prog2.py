#5. pop() :
'''
        It removes the entry associated with the specifed key and returns the corresponding vlaue. 
	If the specified key is not available the we will get KeyError. 
'''
language = {101:'Python',102:'Java',103:'Ruby',104:'Perl'}

print('Language ',language)

print('language.pop(102) : ',language.pop(102))

print('Language ',language)

print('language.pop() : ',language.pop()) #TypeError: pop expected at least 1 argument, got 0
