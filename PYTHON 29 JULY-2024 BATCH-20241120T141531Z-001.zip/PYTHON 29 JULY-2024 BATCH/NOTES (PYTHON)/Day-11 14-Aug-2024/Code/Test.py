bank={}
account=[]

for i in range(5):
    accno = int(input('Enter Account Number:'))
    account.append(input('Enter Name:'))
    account.append(int(input('Enter Balace :')))

    bank[accno]=account.copy()
    account.clear()
print('\n\nAccount Details')
for key,value in bank.items():
    print(f'{key}: {value}')
