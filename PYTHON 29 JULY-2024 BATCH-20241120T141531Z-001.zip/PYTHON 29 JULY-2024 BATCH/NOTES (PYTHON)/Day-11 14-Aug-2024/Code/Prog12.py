#WAP to input string from user at runtime and make dictionary 
#example :  s1 = 'Python is very easy language'
#Output : d1 = {'Python': 6, 'is':2,'very':4,'easy':4,'language': 8}

s1 = 'Python is very easy language'
d = {word : len(word)  for word in s1.split()}

for word, length  in d.items():
    print(f'{word} : {length}')


#Output
'''
Python : 6
is : 2
very : 4
easy : 4
language : 8
'''
