#4. get() : To get the value associated with key

d = dict([(101 , 'Computer'),(102,'Laptop'),(103,'Mobile')])

#print(d[501])
#print(d.get(501))
print(d.get(501,'Prog1.py'))

print('Thank you')
print('Program end here...')

