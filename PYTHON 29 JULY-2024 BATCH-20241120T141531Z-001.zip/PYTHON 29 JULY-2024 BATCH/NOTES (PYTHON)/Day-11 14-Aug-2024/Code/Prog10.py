#WAP to enter five bank record from user at runtime. 
'''
Accno 
Name 
Balance

Then we perform some transaction using accno....
1. Withdraw 
2. Deposit
3. Transfer
'''
bank={}     #Dictionary

bank[101] = ['Rakesh', 50000]
bank[102] = ['Dinesh', 45000]
bank[103] = ['Istiyak', 25000]
bank[104] = ['Rajesh', 25000]
bank[105] = ['Deepak', 1000]

''' 
print('\n\nAccount Details')
for key,value in bank.items():
    print(f'{key} : {value}')
'''
#Phase - 2
accno = int(input('Enter Account : '))
acc_info = bank.get(accno)
if acc_info != None:
    print(f'Account Details : {accno}, {acc_info}')
    print('1. Withdraw\n2. Deposit\n3. Transfer')
    option = int(input('Select Option : '))
    if option == 1:
        w_amt = int(input('Enter Withdrawl Amount : '))
        balance = acc_info[1]
        if w_amt <= balance:
            balance = balance - w_amt
            print(f'Rs. {w_amt} Withraw Succesfully')
            print(f'Remaing Balance is Rs.{balance}')
        else:
            print('Insufficient Balance ')
 
    elif option == 2 :
        print('Deposit')
    elif option == 3:
        pripnt('Transfer')
    else:
        print('Invalid Option')
else:
    print('Account Not Found...')

print('Thank you ')























