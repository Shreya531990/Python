#WAP to enter five bank record from user at runtime. 
'''
Accno 
Name 
Balance

Then we perform some transaction using accno....
1. Withdraw 
2. Deposit
3. Transfer
'''
bank={}     #Dictionary
account=[]  #List

for i in range(5):
    accno = int(input('Enter Account : '))
    account.append(input('Enter Name : '))
    account.append(int(input('Enter Balance : ')))
    bank[accno]=account.copy() 
    account.clear()  # List Clear function to remove list items..
 
print('\n\nAccount Details')
for key,value in bank.items():
    print(f'{key} : {value}')
