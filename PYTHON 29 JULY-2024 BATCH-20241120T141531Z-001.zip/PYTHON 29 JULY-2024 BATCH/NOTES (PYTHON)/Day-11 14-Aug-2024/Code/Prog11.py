#Dictionary Comprehension :

#d_square = {1:1,2:4,3:9,4:16,5:25}
#d_cube = {1:1, 2:8, 3 :27, 4:64, 5:125 }


d_square = { x : x * x for x in range(1,6)}
print('d_square : ',d_square)


d_cube = { x : x ** 3 for x in range(1,6)}
print('\nd_cube : ',d_cube)
