#10 . copy() : To create exactly() duplicate dictionary ( cloned copy)

language = {101:'Python',102:'Java',103:'Ruby',104:'Perl'}

courses = language.copy()

print('Language ',language)
print('Id of language : ',id(language))

print('\n\nCourses ',courses)
print('Id of courses : ',id(courses))
