from  tkinter import *
from tkinter import ttk
from tkinter import filedialog
from PIL import Image ,ImageTk
from tkcalendar import Calendar,DateEntry
import os

main = Tk()
main.title('My First App')

w = main.winfo_screenwidth()
h = main.winfo_screenheight()

#main.geometry("%dx%d+0+0"%(w,h))
main.geometry("600x600")
main.resizable(0,0)

#String Vaddriable
sCity = StringVar()
sGender = StringVar()
sSkill1=IntVar()
sSkill2=IntVar()
sSkill3=IntVar()


#Functions
def submit():
    city = sCity.get()
    print('City ',city)
    print("Skill 3 ",sSkill3.get())
    gender = sGender.get()
    print('Gender ',gender)
    if sSkill1.get() == 1:
        print("Python")
    if sSkill2.get() == 1:
        print("SQL")
    if sSkill3.get() == 1:
        print("Excel")
    regDate = calRegDate.get()
    print('Registration Date ',regDate)
    
def upload_image():
    imgPath = filedialog.askopenfilename(initialdir = os.getcwd())
    print('Image Path ',imgPath)
    global selectedpicture
    selectedpicture = ImageTk.PhotoImage(file = imgPath)
    lblImage.configure(image=selectedpicture,height=150,width=150)



#Frames Design
frmTop = Frame(main,height=100,width=600,bg='Red')
frmTop.pack(fill=X)

frmMid = Frame(main,height=100,width=w,bg='Yellow')
frmMid.pack(side=LEFT,fill=Y)

frmBottom = Frame(main,height=100,width=100,bg='Green')
frmBottom.pack(side=BOTTOM,fill=Y)

frmLeft = Frame(frmMid,height=200,width=200,bg='lightgreen')
frmLeft.pack(side=LEFT,fill=Y)

frmCenter = LabelFrame(frmMid,text="Student Info",height=200,width=600,bg='yellow')
frmCenter.pack(side=LEFT,padx=5,pady=5,fill=Y)

frmRight = LabelFrame(frmMid,text="Student Image",height=200,width=600,bg='yellow')
frmRight.pack(side=LEFT,padx=5,pady=5,fill=Y)
#Widgets
lblHeading = Label(frmTop,text='Welcome to TG',font=("impact",30),bg="Red",fg="Yellow")
lblHeading.pack(pady=20)

lblRollNo = Label(frmLeft,text="Roll No ")
lblRollNo.place(x=10,y=10)

#Image Upload
lblImage = Label(frmRight,text='Image')
lblImage.pack()

btnUpload = Button(frmRight,text='Upload',command = upload_image)
btnUpload.pack(pady=5)

#Combo Box
Label(frmCenter,text='City ').place(x=10,y=20)
ttk.Combobox(frmCenter,values=['Delhi','Mumbai','Jaipur','Gurugram'],textvariable = sCity).place(x=100,y=20)

#Radio Button
Label(frmCenter,text='Gender').place(x=10,y=50)
ttk.Radiobutton(frmCenter,text='Male',variable=sGender,value='Male').place(x=10,y=80)
ttk.Radiobutton(frmCenter,text='Female',variable=sGender,value='Female').place(x=100,y=80)

#Checkbox
Label(frmCenter,text='Skillset ').place(x=10,y=110)
cbSkill1 = ttk.Checkbutton(frmCenter,text='Python',variable =sSkill1)
cbSkill1.place(x=10,y=140)
cbSkill2=ttk.Checkbutton(frmCenter,text='SQL',variable =sSkill2)
cbSkill2.place(x=10,y=170)
cbSkill3=ttk.Checkbutton(frmCenter,text='Excel',variable =sSkill3)
cbSkill3.place(x=10,y=200)

#Calendar
Label(frmCenter,text='Registration Date').place(x=10,y=230)
calRegDate = DateEntry(frmCenter,date_pattern='dd/mm/yyyy')
calRegDate.place(x=150,y=230)








#Submit Button
Button(frmCenter,text='Submit',command = submit).place(x=200,y=300)

main.mainloop()

