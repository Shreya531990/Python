from tkinter import *
main = Tk()
main.geometry("400x400")

#Class
class Registration(Toplevel):
    def __init__(self):
        Toplevel.__init__(self)
        self.geometry("400x400")
        Label(self,text="Registration").place(x=200,y=200)
    
    

#Functions

def login():
    app=Registration()


Button(main,text='Login',command=login).place(x=200,y=200)
main.mainloop()



