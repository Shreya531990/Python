#Cloning : The process of creating exactly duplicate independed object is called cloning..

lst1 = [10,20,30,40,50]

#lst2 = lst1        #Aliasing
#lst2 = lst1.copy()  #Cloning

lst2 = lst1[::] #Using Slice Opertor we do Cloning 

print('List 1 ',lst1)
print('Id of List 1 ',id(lst1))

print('\nList 2 ',lst2)
print('Id of List 2 ',id(lst2))

lst2[0]='Mango'

print('\nAfter changes')
print('List 1 ',lst1)
print('Id of List 1 ',id(lst1))

print('\nList 2 ',lst2)
print('Id of List 2 ',id(lst2))

