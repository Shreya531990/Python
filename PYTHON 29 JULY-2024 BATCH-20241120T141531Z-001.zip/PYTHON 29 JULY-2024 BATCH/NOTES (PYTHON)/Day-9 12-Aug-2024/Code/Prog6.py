#Nested List : Matrix 3 x 3

matrix = [[1,2,3],[4,5,6],[7,8,9]]

print(matrix)

for lst in matrix:
    print(lst)

print('\n------------')
for lst in matrix:
    for element in lst :
        print(element,end='\t')
    print()
