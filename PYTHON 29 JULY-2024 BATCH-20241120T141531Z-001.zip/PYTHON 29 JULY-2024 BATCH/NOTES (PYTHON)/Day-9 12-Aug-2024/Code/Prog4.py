#Copy method will create a shallow copy for list object.

lst1=[10,20,30,['Apple','Mango','Orange']]

lst2 = lst1.copy()

print('List 1 ',lst1)
print('\nList 2 ',lst2)

#lst2[0]='999'
lst2[3][0]=999
print('\nAfter Changes')
print('List 1 ',lst1)
print('\nList 2 ',lst2)



