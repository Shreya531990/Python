'''The problem in this approach is by using
one reference variable if we are changing content,
then those changes will be reflected to the other reference variable.'''

lst1 = [10,20,30,40,50]
lst2 = lst1

print('List 1 ',lst1)
print('List 2 ',lst2)

lst2[0]='Apple'

print('\nAfter changes')
print('List 1 ',lst1)
print('List 2 ',lst2)



