s1 = "The Quick Brown Fox Jumps Over A Lazy Dog"

#Reverse each word using List Comprehension....
#Output :  "ehT kciuQ nworB ...."

s = "The Quick Brown Fox Jumps Over A Lazy Dog"
lst = s.split()
lst2=[]
for word in lst:
    lst2.append(word[::-1])
    
s2=" ".join(lst2)

print(s2)


#Using List Comprehension
s1 = "The Quick Brown Fox Jumps Over A Lazy Dog"
s3 = ' '.join([word[::-1] for word in s1.split()])
print(s3)
