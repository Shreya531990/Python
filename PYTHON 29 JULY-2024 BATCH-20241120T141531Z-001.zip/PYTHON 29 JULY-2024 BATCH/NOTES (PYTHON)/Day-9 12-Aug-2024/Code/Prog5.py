#Deep Copy

import copy

lst1=[10,20,30,['Apple','Mango','Orange']]

lst2 = copy.deepcopy(lst1) #Deep Copy

print('List 1 ',lst1)
print('\nList 2 ',lst2)

#lst2[0]='999'
lst2[3][0]=999
print('\nAfter Changes')
print('List 1 ',lst1)
print('\nList 2 ',lst2)



