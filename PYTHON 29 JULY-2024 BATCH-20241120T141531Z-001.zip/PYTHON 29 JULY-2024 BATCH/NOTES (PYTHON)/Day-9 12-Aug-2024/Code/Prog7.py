#WAP to input square of each number in range(1,11) and create a list object.

lst_square=[]
for i in range(1,11):
    lst_square.append(i*i)

print('List Square ',lst_square)




#Using List Comprehension

lst_square2=[i*i  for i in range(1,11)]

print('List Square 2 ',lst_square2)
