s1='Python is an easy language'

lst=[]
for word in s1.split():
    lst.append(word[::-1])


s2 = ' '.join(lst)
print(s2)
