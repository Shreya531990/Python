#WAP to input in a list object the square of even number....

#Example : 
lst=[]
for i in range(1,11):
    if i % 2 == 0:
        lst.append(i*i)

print('List ',lst)



#Using List Comprehension
lst2 = [i*i for i in range(1,11) if i % 2 == 0]
print('List 2 ',lst2)
