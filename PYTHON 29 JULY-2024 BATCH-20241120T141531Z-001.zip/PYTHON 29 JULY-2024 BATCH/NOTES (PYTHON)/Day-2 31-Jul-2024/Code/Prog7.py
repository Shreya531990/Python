p1=123
p2=1234
p3=763
p4=12
total = p1 + p2 + p3 + p4

print('P1    :',p1)
print('P2    :',p2)
print('P3    :',p3)
print('P4    :',p4)
print('Total :',total)

print('\n------------------\n')
print('P1    : %5d'%(p1))
print('P2    : %5d'%(p2))
print('P3    : %5d'%(p3))
print('P4    : %5d'%(p4))
print('Total : %5d'%(total))
