#Form-8 print() with replacement operator { }

name = 'Rakesh'
salary = 50000
age = 21


print('Your name {} , Salary {} and Age {}'.format(name,salary,age))
#Output : Your name Rakesh , Salary 50000 and Age 21


print('Your name {2} , Salary {0} and Age {1}'.format(salary,age,name))
#Output : Your name Rakesh , Salary 50000 and Age 21


print('Your name {x} , Salary {z} and Age {y}'.format(x=name,y=age,z=salary))
#Output : Your name Rakesh , Salary 50000 and Age 21



