#Form-6 : print(String, variable list) :
#We can use print() statement with String and any number of arguments.

name = 'Rakesh'
age = 21
sub1 = 'Python'
sub2 = 'Django'

print('Your Name is ',name,' and your age is ',age,' \nSubject 1 ',sub1,'\nSubject 2 ',sub2)

