#Form-2 # print(String)

print('Hello Python ')
print('Hi, Techincal Guftgu')


#We can use escape characters also
print('Hello\nPython')     #\n : new line character
print('Technical\tGuftgu') #\t : tab space..


#We can use repetetion operator (*) in the string

print('Technical Gugftgu \n'*3)


#We can use multiplication operator (*) in the integer
print(2*6)


print('Techincal'+'Guftgu')

fname ='Rakesh'
lname ='Sharma'

fullname = fname +' '+ lname
print('Full Name : ',fullname)


