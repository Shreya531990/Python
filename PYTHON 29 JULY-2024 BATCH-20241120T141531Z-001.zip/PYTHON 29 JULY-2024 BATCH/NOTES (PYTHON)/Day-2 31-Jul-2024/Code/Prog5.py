#Form-5 print(object) statement :
'''
We can pass any object ( like tupel, list, string,set etc)
as argument to the print() statement....
'''

lst = [10,20,30]
tp = (10,20,30)

print(lst)
print(tp)
