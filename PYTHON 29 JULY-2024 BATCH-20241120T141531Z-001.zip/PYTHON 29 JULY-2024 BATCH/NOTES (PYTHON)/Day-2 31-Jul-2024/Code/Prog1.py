print('First Line')
print()
print('Second Line')

#print statement have some default attributes
#1. end . Its default value is \n mean New Line
#2. sep

print('This is first line',end='')
print('This is second line')
