#Form-7 : print(formatted string)
'''
%d	==> int
%f 	==> float
%s	==> String type

Syntax : print("Formatted String "%(variable list))
'''



name = 'Rakesh'
age = 21
percentage = 97.45
sub2 = 'Django'

print('Your name %s \nAge %d \nPercentage %f'%(name,age,percentage))

print('Your name %s \nAge %d \nPercentage %.2f'%(name,age,percentage))

print('Your name %s \nAge %d \nPercentage %.2f'%(name,age,percentage))

print(f'Your name is {name}, My age is {age}. I got marks percentage {percentage}')



