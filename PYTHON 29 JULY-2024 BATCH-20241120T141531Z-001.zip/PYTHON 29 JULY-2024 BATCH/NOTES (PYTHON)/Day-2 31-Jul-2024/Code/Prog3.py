#Form - 3 : print() function with variable number of arguments. 

a = 10
b = 20
c = 30

print('the numbers are ',a,b,c)

print('the numbers are ',a,b,c,sep=',')
