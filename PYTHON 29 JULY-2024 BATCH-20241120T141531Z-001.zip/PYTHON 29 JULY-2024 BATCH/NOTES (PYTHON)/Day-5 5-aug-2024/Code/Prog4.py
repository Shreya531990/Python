#if-elif-else statement : Multiple Options 
'''
Syntax :

if condtion-1:
      statement-1
elif condtion-2 :
      statement-2
else :
      statement-3
'''
#Example :
print('Welcome to SBI Bank.')
print('1. Withdraw')
print('2. Deposit')
print('3. Balance')

option =int(input('Select any option : '))

if option == 1:
    print('Withdraw Option Selected')
elif option == 2:
    print('Deposit Option Selected')
elif option == 3:
    print('Balance Option Selected')
else:
    print('Invalid Option...')
