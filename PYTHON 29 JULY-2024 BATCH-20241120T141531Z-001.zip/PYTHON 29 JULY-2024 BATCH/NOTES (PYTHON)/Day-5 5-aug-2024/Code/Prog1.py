#1. Conditional Statements.  : Decision Making and Branching Statement
#WAP to enter pin or password :

pin = int(input('Enter Pin : '))

if pin == 1234 :
    print('Your pin is correct.')

print('Thank you')




