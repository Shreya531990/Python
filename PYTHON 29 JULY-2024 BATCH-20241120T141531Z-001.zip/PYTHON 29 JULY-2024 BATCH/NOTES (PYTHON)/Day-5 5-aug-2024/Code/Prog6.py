'''Electricity Bill Calculation...
Rate Slab : 
1. 0   - 100 	=>  2 per unit
2. 101 - 200 	=>  4 per unit
3. 201 - 300 	=>  6 per unit
4. Above 300 	=>  8 per unit
Case 1 :  
Unit Consumed => 150 units 
	1. First Hundred Units :- 200
	2. 101 to 150 : 50 Units :- 200
	Total Bill Amount : 400 Rupees '''

units = int(input('Enter Units Consumed : '))
bill_amt = 0
if units <= 100:
    bill_amt = units * 2
elif units <= 200:
    bill_amt = 200 + (units - 100)* 4
elif units <= 300:
    bill_amt = 200 + 400 + (units - 200)*6
else:
    bill_amt = 200 + 400 + 600 + (units - 300)*8

print('Bill Amount : ',bill_amt)
