#If-Else statement with multiple statement
pin = int(input('Enter Pin : '))

if pin == 1234:
    print('My PAN Number is Au2334QWER1')
    print('My Aadhar Number is 1234 4321 1212')
else :
    print('Incorrect Pin')

print('Thank you')




    

