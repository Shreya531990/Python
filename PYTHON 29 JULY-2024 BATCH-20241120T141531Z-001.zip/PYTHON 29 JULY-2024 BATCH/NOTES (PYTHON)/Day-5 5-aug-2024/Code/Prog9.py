#WAP to input 10 random numbers from user find the count of even and odd numbers.
print('Enter 10 Random numbers ')

even = 0
odd = 0
for i in range(10):
    num = int(input(f'Enter Number  {i+1} :'))
    if num % 2 == 0:
        even = even + 1
    else:
        odd = odd + 1

print('Count of Even Numbers : ',even)
print('Count of Odd Numbers  : ',odd)
