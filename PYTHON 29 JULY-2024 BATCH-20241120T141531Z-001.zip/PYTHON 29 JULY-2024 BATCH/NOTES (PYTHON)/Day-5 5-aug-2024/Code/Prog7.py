#Range Data Type :

for i in range(10):
    print(i)


print('\n-------------------')
for i in range(10,21):
    print(i)

print('\n-------------------')
for i in range(10,21,2):
    print(i)


print('\n-------------------')
for i in range(21,10,-1):
    print(i)


print('\n-------------------')
for i in range(1,10,-1):
    print(i)
