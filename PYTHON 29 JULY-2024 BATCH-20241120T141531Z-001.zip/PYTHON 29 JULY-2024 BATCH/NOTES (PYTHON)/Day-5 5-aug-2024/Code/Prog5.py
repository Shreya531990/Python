#d. nested-if statement	: If inside if statement
#WAP for Loan Approval using Nested if statement
salary = int(input('Enter Salary : '))
if salary >= 25000:
    print('Salay Matched Criteria')
    age = int(input("Enter Age :"))
    if age>= 25:
        print('Age Matched Criteria')
        exp = int(input('Matched Criteria'))
        if exp >= 5:
            print('Loan Approved')
        else:
            print('Loan Rejected')
    else:
        print('Loan Rejected')
            
else:
    print("Salary Doesn't Match Criteria ")
    print('loan rejected')
